"""Supervisor de Webots: ejecuta episodios de carrera, conecta agentes y registra metricas.
Escenario: config/scenario.json (o la ruta en la variable de entorno SCENARIO)."""
import csv
import json
import os
import time

from controller import Supervisor

from agents import build_agent
from race_env import N_ACTIONS, OBS_DIM, RaceEnv, SimulationEnded

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
FIELDS = ["episode", "lane", "agent", "outcome", "return", "decisions", "collisions",
          "interventions", "finish_time_s", "final_dist", "start_y", "goal_x", "winner"]


def main():
    cfg_path = os.environ.get("SCENARIO", os.path.join(ROOT, "config", "scenario.json"))
    with open(cfg_path) as fh:
        cfg = json.load(fh)
    run_id = cfg.get("runId") or time.strftime("run_%Y%m%d_%H%M%S")
    out_dir = os.path.join(ROOT, "results", run_id)
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "scenario_snapshot.json"), "w") as fh:
        json.dump(cfg, fh, indent=2)

    sup = Supervisor()
    env = RaceEnv(sup, cfg)
    agents = [build_agent(n, OBS_DIM, N_ACTIONS, seed=cfg["seed"] + i)
              for i, n in enumerate(cfg["agents"][:len(env.lanes)])]
    if len(agents) != len(env.lanes):
        raise RuntimeError("scenario.agents debe tener un agente por carril")
    training = cfg["mode"] == "train"

    with open(os.path.join(out_dir, "episodes.csv"), "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDS)
        writer.writeheader()
        try:
            for ep in range(cfg["episode"]["count"]):
                obs = env.reset()
                while not env.all_done():
                    actions = [agents[i].act(obs[i], training) if not env.lanes[i].done else 0
                               for i in range(len(agents))]
                    was_done = [l.done for l in env.lanes]
                    nxt, rewards, dones, _ = env.step(actions)
                    for i, ag in enumerate(agents):
                        if not was_done[i]:
                            ag.observe(obs[i], actions[i], rewards[i], nxt[i], dones[i])
                    obs = nxt
                finishers = [l for l in env.lanes if l.finish_time is not None]
                winner = min(finishers, key=lambda l: l.finish_time).index if finishers else ""
                for i, lane in enumerate(env.lanes):
                    row = env.summary(lane)
                    row.update(episode=ep, agent=agents[i].name, winner=int(winner == i) if winner != "" else 0)
                    writer.writerow({k: row.get(k, "") for k in FIELDS})
                    agents[i].end_episode(row)
                fh.flush()
                print("[supervisor] episodio %d: %s" % (ep, [(l.outcome, round(l.ret, 1)) for l in env.lanes]))
        except SimulationEnded:
            print("[supervisor] simulacion terminada por Webots")
            return
    print("[supervisor] listo; resultados en", out_dir)
    if cfg.get("quitWhenFinished"):
        sup.simulationQuit(0)
    else:
        sup.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)


if __name__ == "__main__":
    main()
