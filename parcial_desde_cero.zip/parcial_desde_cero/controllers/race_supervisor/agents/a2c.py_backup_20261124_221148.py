"""Advantage Actor-Critic (A2C) con actualización al finalizar cada episodio."""
import os
import numpy as np
import torch
import torch.nn.functional as F
from torch import optim
from torch.distributions import Categorical

from agents.base import Agent
from agents.networks import DEVICE, ActorCritic, obs_tensor


class A2CAgent(Agent):
    name = "a2c"

    def __init__(self, obs_dim, n_actions, seed=0, params=None):
        super().__init__(obs_dim, n_actions, seed, params)
        torch.manual_seed(seed)
        p = self.params
        self.gamma = float(p.get("gamma", 0.99))
        self.value_coef = float(p.get("value_coef", 0.5))
        self.entropy_coef = float(p.get("entropy_coef", 0.01))
        self.model = ActorCritic(obs_dim, n_actions).to(DEVICE)
        self.optimizer = optim.Adam(self.model.parameters(), lr=float(p.get("learning_rate", 3e-4)))
        self.rollout = []
        self._training = True
        self.last_loss = None

    def act(self, obs, training=True):
        self._training = bool(training)
        with torch.no_grad():
            logits, _ = self.model(obs_tensor(obs))
            dist = Categorical(logits=logits)
            action = dist.sample() if training else torch.argmax(logits, dim=-1)
        return int(action.item())

    def observe(self, obs, action, reward, next_obs, done):
        if self._training:
            self.rollout.append((np.asarray(obs, dtype=np.float32), int(action),
                                 float(reward), np.asarray(next_obs, dtype=np.float32), bool(done)))

    def end_episode(self, summary):
        if not self._training or not self.rollout:
            self.rollout.clear()
            return
        returns = []
        running = 0.0
        for _, _, reward, _, done in reversed(self.rollout):
            running = reward + self.gamma * running * (1.0 - float(done))
            returns.append(running)
        returns.reverse()
        states = torch.as_tensor(np.asarray([x[0] for x in self.rollout]), dtype=torch.float32, device=DEVICE)
        actions = torch.as_tensor([x[1] for x in self.rollout], dtype=torch.int64, device=DEVICE)
        targets = torch.as_tensor(returns, dtype=torch.float32, device=DEVICE)
        logits, values = self.model(states)
        dist = Categorical(logits=logits)
        advantages = targets - values
        actor_loss = -(dist.log_prob(actions) * advantages.detach()).mean()
        critic_loss = F.mse_loss(values, targets)
        entropy = dist.entropy().mean()
        loss = actor_loss + self.value_coef * critic_loss - self.entropy_coef * entropy
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
        self.optimizer.step()
        self.last_loss = float(loss.item())
        self.rollout.clear()

    def save(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        torch.save({"algorithm": self.name, "model": self.model.state_dict(),
                    "optimizer": self.optimizer.state_dict()}, path)

    def load(self, path):
        data = torch.load(path, map_location=DEVICE)
        self.model.load_state_dict(data["model"])
        if "optimizer" in data:
            self.optimizer.load_state_dict(data["optimizer"])
